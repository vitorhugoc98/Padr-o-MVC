<template>
  <div style="padding-top: 160px;padding-left: 60px;padding-right: 60px">

    <div style="font-weight: bold; font-size: 25px">Smart Buss </div><div style="padding-bottom: 95px; font-size: 15px"> Uma forma mais Smart de se mover!
    <div style="font-size: 12px">Esqueceu a senhddddddddddda?</div></div>

    <q-btn color="primary" label="Entrar" />
    <q-btn color="primary" label="Cadastrar"/>


  </div>



</template>

<script>
    export default {
        name: "Login"
    }
</script>

<style scoped>

</style>
