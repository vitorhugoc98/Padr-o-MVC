<form action="CadastroUsuario.php" method="post">
    <table>
        <tr>
            <td>Nome</td>
            <td><input name = "nome" id="nome"></td>
        </tr>
        <tr>
            <td>Login</td>
            <td><input name = "login" id="login"></td>
        </tr>
        <tr>
            <td>Senha</td>
            <td><input type="password" name = "senha" id="senha"></td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="btnSubmit" value="Enviar">
            </td>
        </tr>
    </table>

</form>



