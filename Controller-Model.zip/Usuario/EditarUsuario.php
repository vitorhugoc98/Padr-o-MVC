<?php
$id = $_POST['id'];
$nome = $_POST['nome'];
$login = $_POST['login'];
$senha = $_POST['senha'];

if($nome == "" || $login == "" || $senha == ""){
    echo "Os campos: Nome; Login e Senha são obrigatórios.";
}else{
    include '../Conexao.php';
    $sql = "UPDATE usuarios SET nome = '$nome', login = '$login', senha = '$senha' where id = $id";
    $resultado = mysqli_query($conexao,$sql) or die(mysqli_error($conexao));
    #echo $sql;
    #var_dump($resultado);

    if($resultado){
        echo "<br />";
        echo "Usuário alterado com sucesso.";
    }
}