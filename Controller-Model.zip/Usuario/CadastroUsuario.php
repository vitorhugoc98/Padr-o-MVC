<?php

var_dump($_POST);


#da erro porque o dolar POST ainda n foi definido, precisamos definir ele
# primeiramente em: TelaCadastroUsuário



$nome = $_POST['nome'];
$login = $_POST['login'];
$senha = $_POST['senha'];

if($nome == "" || $login == "" || $senha == ""){
    echo "Os campos: Nome; Login e Senha são obrigatórios.";
}else{
    include '../Conexao.php';
    $sql = "INSERT INTO usuarios (nome, login, senha) value ('nome', 'login', 'senha')";
    $resultado = mysqli_query($conexao,$sql) or die(mysqli_error($conexao));
    echo $sql;
    var_dump($resultado);

    if($resultado){
        echo "<br />";
        echo "Usuário cadastrado com sucesso.";
    }
}