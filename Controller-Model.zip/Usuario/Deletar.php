<?php
$id = $_GET['id'];

include '../Conexao.php';

$sql = "delete from usuarios where id = '$id'";

$resultado = mysqli_query($conexao, $sql) or die(mysqli_error($sql));

if($resultado){
    echo "Usuário deletado com suscesso.";
}