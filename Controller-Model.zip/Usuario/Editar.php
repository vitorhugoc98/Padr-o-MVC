<pre>
<?php

$id = $_GET['id'];

include '../Conexao.php';

$sql = "select * from usuarios where id = '$id'";

$resultado = mysqli_query($conexao, $sql) or die(mysqli_error($sql));

$dados = mysqli_fetch_all($resultado);


#var_dump($dados);
?>
    <form action="EditarUsuario.php" method="post">
        <input type="hidden" name="id" id="id" value="<?php echo $dados[0][0] ?>" ">
    <table>
        <tr>
            <td>Nome</td>
            <td><input name = "nome" id="nome" value="<?php echo $dados[0][1] ?>"></td>
        </tr>
        <tr>
            <td>Login</td>
            <td><input name = "login" id="login" value="<?php echo $dados[0][2] ?>"></td>
        </tr>
        <tr>
            <td>Senha</td>
            <td><input type="password" name = "senha" id="senha" value="<?php echo $dados[0][3] ?>" ></td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="btnSubmit" value="Enviar">
            </td>
        </tr>
    </table>

</form>

</pre>