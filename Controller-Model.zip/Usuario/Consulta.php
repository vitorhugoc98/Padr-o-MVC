<table border="2">
    <tr>
        <td>Código</td>
        <td>Nome</td>
        <td>Login</td>
        <td>Senha</td>
        <td>Editar</td>
        <td>Deletar</td>
    </tr>
<?php

include '../Conexao.php';

$sql = "SELECT id, nome, login, senha from usuarios";

$resultado = mysqli_query($conexao, $sql);

$dados = mysqli_fetch_all($resultado);

#var_dump($dados);

for($i=0; $i<count($dados); $i++){

    ?>
    <tr>
        <td> <?php echo $dados[$i]["0"] ?> </td>
        <td> <?php echo $dados[$i]["1"] ?> </td>
        <td> <?php echo $dados[$i]["2"] ?> </td>
        <td> <?php echo $dados[$i]["3"] ?> </td>
        <td><a href = "Editar.php?id=<?php echo $dados[$i][0]?>"> Editar </a></td>
        <td><a href = "Deletar.php?id=<?php echo $dados[$i][0]?>"> Deletar </a></td>
    </tr>
    <?php
}

?>
</table>