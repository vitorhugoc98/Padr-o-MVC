<?php

    $conexao = mysqli_connect('localhost',"root","","crud") or die(mysqli_error());


