<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-type: application/json");

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $dados = json_decode(file_get_contents('php://input'), true);

    //var_dump($dados);

    if ($dados != null) {
        $nome = $dados['nome'];
        $login = $dados['login'];
        $senha = $dados['senha'];

        if ($nome == "" || $login == "" || $senha == "") {
            $mensagem = "Os campos: Nome; Login e Senha são obrigatórios.";
        } else {
            include '../Conexao.php';

            $sql = "INSERT INTO usuarios (nome, login, senha) value ('$nome', '$login', '$senha')";
            $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
            if ($resultado) {
                $mensagem = "Usuário cadastrado com sucesso.";
            }
        }
    }
}else{
    $mensagem = "Use o metodo POST";
}
$retorno["Mensagem"] = $mensagem;
echo json_encode($retorno);


