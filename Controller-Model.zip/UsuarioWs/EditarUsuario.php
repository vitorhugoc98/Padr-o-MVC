<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("content-type: application/json");
header("Access-Control-Allow-Methods: PUT");

if ($_SERVER['REQUEST_METHOD'] == "PUT") {
    $req = file_get_contents('php://input');
    $dados = json_decode($req, true);


    if ($dados != null) {
        $id = $dados['id'];
        $nome = $dados['nome'];
        $login = $dados['login'];
        $senha = @$dados['senha'];

        if ($senha != "") {
            $mensagem = "Cadastrado com sucesso";
        } else if ($login == "") {
            $mensagem = "Digite um login";
        } else {


            include '../Conexao.php';

            $sql = "UPDATE usuarios SET nome = '$nome', login = '$login' ";
            if ($login != "") {
                $sql = $sql . ", senha = '$senha'";
            }

            $sql = $sql . "where id = '$id'";


            $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
            if ($resultado) {
                $mensagem = "Usuario Alterado!!!";
            }


        }
    } else {
        $mensagem = "Informe um Usuário";
    }
} else {
    $mensagem = "Utilize o Metódo PUT";
}
$retorno["Mensagem"] = $mensagem;
echo json_encode($retorno);