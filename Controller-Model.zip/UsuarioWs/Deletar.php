<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: DELETE");
header("Content-type: application/json");

if($_SERVER['REQUEST_METHOD'] == "DELETE") {

    $dados = json_decode(file_get_contents('php://input'), true);

    if ($dados != null) {

        include '../Conexao.php';

        $id = $dados['id'];

        $sql = "delete from usuarios where id = '$id'";

        $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($sql));

        if ($resultado) {
            $mensagem = "Usuário deletado com suscesso.";
        }
    } else {
        $mensagem = "Informe um usuário.";
    }
}else{
    $mensagem = "Use o metodo Delete";
}

$retorno["Mensagem"] = $mensagem;
echo json_encode($retorno);

