<template>

  <div style="padding-top: 160px;padding-left: 80px;padding-right: 80px">
    <div style="font-weight: bold; font-size: 25px">Smart Buss </div><div style="padding-bottom: 95px; font-size: 15px"> Uma forma mais Smart de se mover!
    <div style="font-size: 12px">Esqueceu a senha?</div></div>

    <img

      alt="Quasar index"
      src="~assets/quasar-logo-full.svg"

    <q-btn color="primary" label="index" />

    <q-btn color="primary" label="Cadastrar" @click=""/>


  </div>

</template>

<script>
export default {
  name: 'PageIndex'
}
</script>
